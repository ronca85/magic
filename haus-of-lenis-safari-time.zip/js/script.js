const imgg1 = document.querySelector('.img-g1');
const txtg1 = document.querySelector('.text-g1');


if (imgg1 !== null) {
    
    imgg1.addEventListener('mouseenter', () => {
        txtg1.classList.add('is-hovered');
        imgg1.classList.add('is-hovered');
    })

    imgg1.addEventListener('mouseleave', () => {
        txtg1.classList.remove('is-hovered');
        imgg1.classList.remove('is-hovered');
    })

}

if (imgg1 !== null) {

    txtg1.addEventListener('mouseenter', () => {
        // txtg1.classList.add('is-hovered');
        imgg1.classList.add('is-hovered');
    })

    txtg1.addEventListener('mouseleave', () => {
        // txtg1.classList.remove('is-hovered');
        imgg1.classList.remove('is-hovered');
    })

}


const circle = document.querySelector('.circle');
const circleimg = document.querySelector('.circle img');

if (circle !== null) {
    circle.addEventListener('mouseenter', () => {
        circle.classList.add('is-hovered');
    })
    
    circle.addEventListener('mouseleave', () => {
        circle.classList.remove('is-hovered');
    })
}

window.addEventListener('load', () => {
    document.querySelector('.loading').remove();
    document.body.classList.add('loaded');
})


if (document.querySelector('.mySwiper') !== null) {

    var swiper = new Swiper('.mySwiper', {
        centeredSlides: true,
        initialSlide: 0,
        slidesPerView: 1.1,
        parallax: true,
        navigation: {
            nextEl: ".swiper-button-next",
            prevEl: ".swiper-button-prev",
        },
        pagination: {
        el: '.swiper-pagination',
        type: 'fraction',
        },
        keyboard: true,
        breakpoints: {
            // when window width is >= 320px
            768: {
              slidesPerView: 1.5,
              spaceBetween: '2%',
            },
             1400: {
              spaceBetween: '5%',
               slidesPerView: 1.5,
            },
          }
    });

}

// Swipers in top-10.html

if (document.querySelector('.mySwiper1') !== null) {

    var swiper = new Swiper(".mySwiper1-thumb", {
        spaceBetween: 16,
        slidesPerView: 4,
        freeMode: true,
        watchSlidesProgress: true,
        preloadImages: false,
        lazy: true
    });
    var swiper2 = new Swiper(".mySwiper1", {
        spaceBetween: 16,
        navigation: {
        nextEl: ".swiper-button-next",
        prevEl: ".swiper-button-prev",
        },
        thumbs: {
        swiper: swiper,
        },
        keyboard: true,
        preloadImages: false,
        lazy: true

    });

    var swiper = new Swiper(".mySwiper2-thumb", {
        spaceBetween: 16,
        slidesPerView: 4,
        freeMode: true,
        watchSlidesProgress: true,
        preloadImages: false,
        lazy: true
    });
    var swiper2 = new Swiper(".mySwiper2", {
        spaceBetween: 16,
        navigation: {
        nextEl: ".swiper-button-next",
        prevEl: ".swiper-button-prev",
        },
        thumbs: {
        swiper: swiper,
        },
        keyboard: true,
        preloadImages: false,
        lazy: true

    });

    var swiper = new Swiper(".mySwiper3-thumb", {
        spaceBetween: 16,
        slidesPerView: 4,
        freeMode: true,
        watchSlidesProgress: true,
        preloadImages: false,
        lazy: true
    });
    var swiper2 = new Swiper(".mySwiper3", {
        spaceBetween: 16,
        navigation: {
        nextEl: ".swiper-button-next",
        prevEl: ".swiper-button-prev",
        },
        thumbs: {
        swiper: swiper,
        },
        keyboard: true,
        preloadImages: false,
        lazy: true

    });

    var swiper = new Swiper(".mySwiper4-thumb", {
        spaceBetween: 16,
        slidesPerView: 4,
        freeMode: true,
        watchSlidesProgress: true,
        preloadImages: false,
        lazy: true
    });
    var swiper2 = new Swiper(".mySwiper4", {
        spaceBetween: 16,
        navigation: {
        nextEl: ".swiper-button-next",
        prevEl: ".swiper-button-prev",
        },
        thumbs: {
        swiper: swiper,
        },
        keyboard: true,
        preloadImages: false,
        lazy: true

    });

    var swiper = new Swiper(".mySwiper5-thumb", {
        spaceBetween: 16,
        slidesPerView: 4,
        freeMode: true,
        watchSlidesProgress: true,
        preloadImages: false,
        lazy: true
    });
    var swiper2 = new Swiper(".mySwiper5", {
        spaceBetween: 16,
        navigation: {
        nextEl: ".swiper-button-next",
        prevEl: ".swiper-button-prev",
        },
        thumbs: {
        swiper: swiper,
        },
        keyboard: true,
        preloadImages: false,
        lazy: true

    });

    var swiper = new Swiper(".mySwiper6-thumb", {
        spaceBetween: 16,
        slidesPerView: 4,
        freeMode: true,
        watchSlidesProgress: true,
        preloadImages: false,
        lazy: true
    });
    var swiper2 = new Swiper(".mySwiper6", {
        spaceBetween: 16,
        navigation: {
        nextEl: ".swiper-button-next",
        prevEl: ".swiper-button-prev",
        },
        thumbs: {
        swiper: swiper,
        },
        keyboard: true,
        preloadImages: false,
        lazy: true

    });

    var swiper = new Swiper(".mySwiper7-thumb", {
        spaceBetween: 16,
        slidesPerView: 4,
        freeMode: true,
        watchSlidesProgress: true,
        preloadImages: false,
        lazy: true
    });
    var swiper2 = new Swiper(".mySwiper7", {
        spaceBetween: 16,
        navigation: {
        nextEl: ".swiper-button-next",
        prevEl: ".swiper-button-prev",
        },
        thumbs: {
        swiper: swiper,
        },
        keyboard: true,
        preloadImages: false,
        lazy: true

    });

    var swiper = new Swiper(".mySwiper8-thumb", {
        spaceBetween: 16,
        slidesPerView: 4,
        freeMode: true,
        watchSlidesProgress: true,
        preloadImages: false,
        lazy: true
    });
    var swiper2 = new Swiper(".mySwiper8", {
        spaceBetween: 16,
        navigation: {
        nextEl: ".swiper-button-next",
        prevEl: ".swiper-button-prev",
        },
        thumbs: {
        swiper: swiper,
        },
        keyboard: true,
        preloadImages: false,
        lazy: true

    });

    var swiper = new Swiper(".mySwiper9-thumb", {
        spaceBetween: 16,
        slidesPerView: 4,
        freeMode: true,
        watchSlidesProgress: true,
        preloadImages: false,
        lazy: true
    });
    var swiper2 = new Swiper(".mySwiper9", {
        spaceBetween: 16,
        navigation: {
        nextEl: ".swiper-button-next",
        prevEl: ".swiper-button-prev",
        },
        thumbs: {
        swiper: swiper,
        },
        keyboard: true,
        preloadImages: false,
        lazy: true

    });

    var swiper = new Swiper(".mySwiper10-thumb", {
        spaceBetween: 16,
        slidesPerView: 4,
        freeMode: true,
        watchSlidesProgress: true,
        preloadImages: false,
        lazy: true
    });
    var swiper2 = new Swiper(".mySwiper10", {
        spaceBetween: 16,
        navigation: {
        nextEl: ".swiper-button-next",
        prevEl: ".swiper-button-prev",
        },
        thumbs: {
        swiper: swiper,
        },
        keyboard: true,
        preloadImages: false,
        lazy: true

    });
}



const toggle = document.querySelector('.toggle-menu');
const menu = document.querySelector('#menu');


toggle.addEventListener('click', () => {
    toggle.classList.toggle('active');
    menu.classList.toggle('open');
    document.body.classList.toggle('nav-is-open');
})